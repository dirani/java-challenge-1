package com.rdirani.bezkoder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BezkoderApplication {

	public static void main(String[] args) {
		SpringApplication.run(BezkoderApplication.class, args);
	}

}
