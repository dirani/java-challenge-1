package com.ram.utils;

public enum RequestOperationName
{
	DELETE
}
