package com.ram.utils;

public enum RequestOperationResult
{
	SUCCESS,ERROR
}
