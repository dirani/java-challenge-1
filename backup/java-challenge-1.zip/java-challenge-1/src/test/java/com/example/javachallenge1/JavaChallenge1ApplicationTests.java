package com.example.javachallenge1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaChallenge1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
